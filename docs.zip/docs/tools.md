---
search:
    exclude: true
---

# Tools

Security/hacking tools by Exploit Notes aurthors.

## darkURLs

Deep and dark website URLs for threat intelligence.

:link: [https://codeberg.org/cowcowdream/darkURLs](https://codeberg.org/cowcowdream/darkURLs)

## OSINT Tools

A curated list of OSINT tools.

:link: [https://start.me/p/gGO61M/osint-tools](https://start.me/p/gGO61M/osint-tools)
