# URL Obfuscation

## Hex Encoding

- [https://codebeautify.org/ip-to-hex-converter](https://codebeautify.org/ip-to-hex-converter)
- [https://www.browserling.com/tools/ip-to-hex](https://www.browserling.com/tools/ip-to-hex)

## @ Spoofing

- `https://www.google.com@evil.com`
- `https://www.facebook.com@evil.com`

## IDN Homograph Attack

- `hxxps://www.аpple.com` (`a` (Latin) -> `а` (Cyrillic))
- `hxxps://www.googlе.com` (`e` (Latin) -> `е` (Cyrillic))

## Qishing

- [https://www.qr-code-generator.com/](https://www.qr-code-generator.com/)
- [https://www.the-qrcode-generator.com/](https://www.the-qrcode-generator.com/)

## Search Engine Click Tracking URL

- Bing: In the Bing search, type the keyword `site:evil.com` (replace it with your desired domain) in the search bar and get the results. Once the results are displayed, we can use the Bing redirect URL such as `https://www.bing.com/ck/a?!&&p=abcd...` by hovering the site title listed in the results. In my easy research, these click tracking URLs are generated in only the following browsers: Microsoft Edge, FireFox with almost default settings.

## Subdomain Spoofing

- `https://www.google.com.evil.com`
- `https://www.facebook.com.evil.com`

## Typosquatting

- `https://www.goog1e.com` (`l` -> `1`)
- `https://www.facabook.com` (`e` -> `a`)

## URL Shortener

- [CreepyLink](https://creepylink.com/)
- [TinyURL](https://tinyurl.com/)
- [Cuttly](https://cutt.ly/)
- [URL Shortener](https://shorter.me/)
